#ifndef Six_Step_Functions_H_
#define Six_Step_Functions_H_

#endif /*Six_Step_Functions_H_*/


uint8_t readHallSensors();
void motorCommutation(void);
