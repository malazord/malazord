# Acionamento_BLDC

Não sei oq to fazendo
